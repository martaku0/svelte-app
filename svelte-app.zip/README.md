# svelte-vite-tailwindcss3-template

This is a fork of Svelte's project template to enable usage of Tailwindcss. Refer to https://github.com/sveltejs/template for more info.

To create a new project based on this template using [degit](https://github.com/Rich-Harris/degit):

```bash
npx degit lukem121/svelte-vite-tailwind-template svelte-app
cd svelte-app
```

_Note that you will need to have [Node.js](https://nodejs.org) installed._

## Get started

Install the dependencies...

```bash
cd svelte-app
npm install
```
